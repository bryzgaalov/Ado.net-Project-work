﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_ADONET_1
{
    public class xDataDoc
    {
        [Key]
        public int xDataDocId { get; set; }
        public string title { get; set; }
        public string pubDate { get; set; }
        public string description { get; set; }
        public string quant { get; set; }
        public string change { get; set; }




    }
}

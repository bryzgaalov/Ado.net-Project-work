﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Xml;
using System.Xml.Linq;

namespace Exam_ADONET_1
{
    class Program
    {
        static string webstring ="http://www.nationalbank.kz/rss/rates.xml";
      public  static  List<xDataDoc> rates = new List<xDataDoc>();
        static void Main(string[] args)
        {
           
            Console.WriteLine("Press the Enter key to start the program ");
        
            Console.WriteLine();
            Console.WriteLine();
            GetRates();
          

            System.Timers.Timer  aTimer = new System.Timers.Timer();
            aTimer.Interval = 300000;
            aTimer.Elapsed += OnTimedEvent;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;

            Console.WriteLine("Press the Enter key to exit the program at any time... ");
            Console.ReadLine();
        }


        public static void OnTimedEvent(Object source, System.Timers.ElapsedEventArgs e)
        {

            updateRates();
        }

        public static List<xDataDoc> GetRates( )
        {
           

         


                XDocument xDoc = new XDocument();
                try
                {
                    xDoc = XDocument.Load(webstring);
                }
                catch (Exception e)
                {
                sendMain(e);
                }
                foreach (var item in xDoc.Descendants("item"))
                {
                    xDataDoc istanance = new xDataDoc();
                    foreach (var items in item.Elements())
                    {



                        foreach (PropertyInfo prop in istanance.GetType().GetProperties())
                        {

                            if (items.Name == prop.Name)
                            {
                                istanance.GetType().GetProperty(prop.Name).SetValue(istanance, items.Value);
                            //   if(items.Name== "pubDate")
                            //{
                            //    istanance.pubDate = Convert.ToDateTime(items.Value) ;
                            //}

                            }


                        }

                    }
              
                    rates.Add(istanance as xDataDoc);
                }
                foreach (var item in rates)
                {
                  

                Console.WriteLine("Валюта: " + item.title);
                Console.WriteLine();
                Console.WriteLine("Курс по отношению к тенге : " + item.description);
                Console.WriteLine("Количество : " + item.quant);
                Console.WriteLine("Обмен : " + item.change);
                Console.WriteLine("Дата публикации : " + item.pubDate);
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();

            }


            using (MyDbContext context = new MyDbContext())
            {

                foreach (var item in rates)
                {
                    context.dataDocs.Add(item);
                    context.SaveChanges();
                }
            }


            

            Console.ReadKey();
                return rates;

            

            




        }


        public static List<xDataDoc> updateRates()
        {
            List<xDataDoc> rates2 = new List<xDataDoc>();




            XDocument xDoc = new XDocument();
            try
            {
                xDoc = XDocument.Load(webstring);
            }
            catch (Exception e)
            {
                sendMain(e);
                return null;

            }
            foreach (var item in xDoc.Descendants("item"))
            {
                Object istanance = Activator.CreateInstance(typeof(xDataDoc));
                foreach (var items in item.Elements())
                {



                    foreach (PropertyInfo prop in istanance.GetType().GetProperties())
                    {

                        if (items.Name == prop.Name)
                        {
                            istanance.GetType().GetProperty(prop.Name).SetValue(istanance, items.Value);


                        }


                    }

                }

                rates2.Add(istanance as xDataDoc);
            }



            rates.ToArray();
            rates2.ToArray();
          


                for(int i = 0; i < rates2.Count; i++) {


                if (rates[i].description == rates2[i].description)
                {
                    Console.WriteLine("Данные оставлись преждними, изменений на валютном рынке не найдено. На экран выведены данные на: " + DateTime.Now);
                   
                    i = rates2.Count;
                }
                else
                {
                    Console.Clear();


                    using (MyDbContext context = new MyDbContext())
                    {

                        foreach (var item2 in rates2)
                        {

                            Console.WriteLine("Валюта: " + item2.title);
                            Console.WriteLine();
                            Console.WriteLine("Курс по отношению к тенге : " + item2.description);
                            Console.WriteLine("Количество : " + item2.quant);
                            Console.WriteLine("Обмен : " + item2.change);
                            Console.WriteLine("Дата публикации : " + item2.pubDate);
                            Console.WriteLine();
                            Console.WriteLine();
                            Console.WriteLine();











                            context.dataDocs.Add(item2);
                            context.SaveChanges();

                        }
                        Console.WriteLine("Были найдены изменения на валютном рынке. На экран выведены данные на: " + DateTime.Now);
                    }




                    return rates2;

                }


                }



            return rates2;

        }


        private static void sendMain( Exception e)
        {
           
                MailAddress fromMailAdress = new MailAddress("yar.bryzgalov2@mail.ru", "Отправитель");
                MailAddress toAdress = new MailAddress("bryzgalov095@gmail.com", "Получатель");
                using (MailMessage mailMessage = new MailMessage(fromMailAdress, toAdress))
                using (SmtpClient smtpClient = new SmtpClient())
                {
                    mailMessage.Subject = "Exception Message";
                    mailMessage.Body = e.Message;

                    smtpClient.Host = "smtp.mail.ru";
                    smtpClient.Port = 587;
                    smtpClient.EnableSsl = true;
                    smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = new NetworkCredential(fromMailAdress.Address, "stvol5678");
                    smtpClient.Send(mailMessage);
                }

                Console.WriteLine("Ваше сообщенеие было успешно отправлено");
           

          


            

        }

    
    

    }
}
